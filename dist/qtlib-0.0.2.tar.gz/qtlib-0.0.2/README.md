# qtlib

a open source project for quantitative trading library